package jp.co.example.controller;

import org.springframework.stereotype.Controller;

//削除のコントローラ　猪瀬
@Controller
public class DeleteController {

}
