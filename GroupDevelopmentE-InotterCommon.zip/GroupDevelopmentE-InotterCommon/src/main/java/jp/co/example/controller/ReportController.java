package jp.co.example.controller;

import org.springframework.stereotype.Controller;

//通報のコントローラ（通報リストは含まない）　石塚
@Controller
public class ReportController {

}
