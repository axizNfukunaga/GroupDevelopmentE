package jp.co.example.service.impl;

import org.springframework.stereotype.Service;

import jp.co.example.service.UsersService;
@Service
public class UsersServiceImpl implements UsersService{

}
