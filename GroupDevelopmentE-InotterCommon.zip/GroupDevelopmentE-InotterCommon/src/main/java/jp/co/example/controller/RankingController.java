package jp.co.example.controller;

import org.springframework.stereotype.Controller;

//いいねランキングのコントローラ　猪瀬
@Controller
public class RankingController {

}
