package jp.co.example.controller;

import org.springframework.stereotype.Controller;
//非同期処理のコントローラ　つぶやき、リプライ、いいね機能　福永
@Controller
public class AsynchronousController {

}
