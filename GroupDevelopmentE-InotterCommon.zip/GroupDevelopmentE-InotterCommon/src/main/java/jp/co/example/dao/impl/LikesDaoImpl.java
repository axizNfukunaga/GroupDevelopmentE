package jp.co.example.dao.impl;

import jp.co.example.dao.LikesDao;

public class LikesDaoImpl implements LikesDao{

}
