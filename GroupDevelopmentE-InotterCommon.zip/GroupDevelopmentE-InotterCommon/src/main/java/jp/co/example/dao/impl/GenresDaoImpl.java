package jp.co.example.dao.impl;

import jp.co.example.dao.GenresDao;

public class GenresDaoImpl implements GenresDao{

}
