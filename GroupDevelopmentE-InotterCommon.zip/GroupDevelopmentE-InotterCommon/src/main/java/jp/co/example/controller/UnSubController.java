package jp.co.example.controller;

import org.springframework.stereotype.Controller;

//退会機能のコントローラ　大崎
@Controller
public class UnSubController {

}
