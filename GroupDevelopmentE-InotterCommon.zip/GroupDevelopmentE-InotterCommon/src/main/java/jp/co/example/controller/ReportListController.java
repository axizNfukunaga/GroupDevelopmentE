package jp.co.example.controller;

import org.springframework.stereotype.Controller;

//通報リスト閲覧のコントローラ　猪瀬
@Controller
public class ReportListController {

}
