package jp.co.example.service.impl;

import org.springframework.stereotype.Service;

import jp.co.example.service.LikesService;
@Service
public class LikesServiceImpl implements LikesService{

}
