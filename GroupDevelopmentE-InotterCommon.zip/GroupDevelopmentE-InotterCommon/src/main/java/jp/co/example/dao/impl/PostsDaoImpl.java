package jp.co.example.dao.impl;

import jp.co.example.dao.PostsDao;

public class PostsDaoImpl implements PostsDao{

}
