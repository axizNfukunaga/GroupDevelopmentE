package jp.co.example.controller;

import org.springframework.stereotype.Controller;

//会員登録のコントローラ　大升
@Controller
public class RegistController {

}
