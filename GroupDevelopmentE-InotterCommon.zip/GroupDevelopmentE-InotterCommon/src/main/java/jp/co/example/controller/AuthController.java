package jp.co.example.controller;

import org.springframework.stereotype.Controller;

//ログイン、ログアウトに関するコントローラ　大崎、大升
@Controller
public class AuthController {

}
