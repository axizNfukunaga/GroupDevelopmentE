package jp.co.example.controller;

import org.springframework.stereotype.Controller;
//会員ユーザーの情報閲覧のコントローラ　花塚
@Controller
public class ReadingController {

}
