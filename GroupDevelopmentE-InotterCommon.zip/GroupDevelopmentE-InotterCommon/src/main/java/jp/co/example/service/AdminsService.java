package jp.co.example.service;

public interface AdminsService {

}
