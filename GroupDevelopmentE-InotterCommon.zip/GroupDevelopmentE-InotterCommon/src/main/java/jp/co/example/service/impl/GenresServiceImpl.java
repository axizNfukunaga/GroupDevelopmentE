package jp.co.example.service.impl;

import org.springframework.stereotype.Service;

import jp.co.example.service.GenresService;

@Service
public class GenresServiceImpl implements GenresService{

}
