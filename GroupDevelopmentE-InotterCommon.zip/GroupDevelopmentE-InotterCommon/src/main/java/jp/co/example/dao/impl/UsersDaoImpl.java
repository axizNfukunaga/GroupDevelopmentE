package jp.co.example.dao.impl;

import jp.co.example.dao.UsersDao;

public class UsersDaoImpl implements UsersDao{

}
