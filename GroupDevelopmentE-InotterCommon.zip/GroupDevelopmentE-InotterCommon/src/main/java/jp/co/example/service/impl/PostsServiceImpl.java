package jp.co.example.service.impl;

import org.springframework.stereotype.Service;

import jp.co.example.service.PostsService;

@Service
public class PostsServiceImpl implements PostsService{

}
