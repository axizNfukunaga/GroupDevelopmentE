package jp.co.example.entity;

public class Form {

}
