package jp.co.example.service;

public interface LikesService {

}
