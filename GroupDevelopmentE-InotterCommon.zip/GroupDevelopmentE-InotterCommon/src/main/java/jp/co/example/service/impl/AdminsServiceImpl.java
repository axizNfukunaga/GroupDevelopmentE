package jp.co.example.service.impl;

import org.springframework.stereotype.Service;

import jp.co.example.service.AdminsService;
@Service
public class AdminsServiceImpl implements AdminsService{

}
