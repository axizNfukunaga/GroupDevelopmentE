package jp.co.example.dao;

public interface GenresDao {

}
