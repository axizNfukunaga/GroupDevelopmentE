package jp.co.example.dao.impl;

import jp.co.example.dao.AdminsDao;

public class AdminsDaoImpl implements AdminsDao{

}
