package jp.co.example.controller;

import org.springframework.stereotype.Controller;
//検索機能に関するコントローラ　石塚
@Controller
public class SearchController {

}
